//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by USB2I2C.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    102
#define IDD_USB2I2C_DIALOG             103
#define IDR_MAINFRAME                   104
#define IDD_DLGEPP                      105
#define IDD_DLGMEM                      106
#define IDD_DLGOTHER                    107
#define IDD_DLGI2C2                     108
#define IDD_BtDisplay                   109
#define IDD_MEMBtDisp                   110
#define IDD_EEPROMRW                    111
#define IDD_DLGBtDisp                   112
#define IDC_EDIT_I2CDEVADD              113
#define IDC_EDIT_I2CDATAADD             114
#define IDC_EDIT_MEMDATA1               115
#define IDC_EDIT_I2CSRDLEN              116
#define IDC_EDIT_MEMLEN1                117
#define IDC_BUTTON_I2CREAD              118
#define IDC_BUTTON_I2CWRITE             119
#define IDC_BUTTON_MEMREAD1             120
#define IDC_EDIT_I2CDATA                121
#define IDC_BUTTON_MEMWRITE1            122
#define IDC_EDIT_I2CSRDDATA             123
#define IDC_EDIT_EPPDATA0               124
#define IDC_EDIT_EPPLEN0                125
#define IDC_EDIT_EPPDATA1               126
#define IDC_EDIT_EPPLEN1                127
#define IDC_BUTTON_EPPREAD0             128
#define IDC_BUTTON_EPPWRITE0            129
#define IDC_BUTTON_EPPREAD1             130
#define IDC_BUTTON_EPPWRITE1            131
#define IDC_EDIT_MEMDATA0               132
#define IDC_EDIT_MEMLEN0                133
#define IDC_BUTTON_MEMREAD0             134
#define IDC_BUTTON_MEMWRITE0            135
#define IDC_WrDate                      136
#define IDC_SEND                        137
#define IDC_RdDate                      138
#define IDC_EDIT_I2CSWRLEN              139
#define IDC_EDIT_I2CSWRDATA             140
#define IDC_ADD0                        141
#define IDC_ADD1                        142
#define IDC_WDateAddr                   143
#define IDC_WDateLen                    144
#define IDC_WDateBuf                    145
#define IDC_RDateAddr                   146
#define IDC_RDateLen                    147
#define IDC_RDateBuf                    148
#define IDC_EDIT7                       149
#define IDC_EDIT8                       150
#define IDC_CHECK1                      151
#define IDC_CHECK2                      152
#define IDC_CHECK3                      153
#define IDC_CHECK4                      154
#define IDC_CHECK5                      155
#define IDC_CHECK6                      156
#define IDC_CHECK7                      157
#define IDC_CHECK8                      158
#define IDC_BtRefresh                   159
#define IDC_CHECK9                      160
#define IDC_CHECK10                     161
#define IDC_CHECK11                     162
#define IDC_CHECK12                     163
#define IDC_CHECK13                     164
#define IDC_CHECK14                     165
#define IDC_CHECK15                     166
#define IDC_CHECK16                     167
#define IDC_RADIO1                      168
#define IDC_RADIO2                      169
#define IDC_RADIO3                      170
#define IDC_RADIO4                      171
#define IDC_RADIO5                      172
#define IDC_RADIO6                      173
#define IDC_RADIO7                      174
#define IDC_RADIO8                      175
#define IDC_RADIO9                      176
#define IDC_RADIO10                     177
#define IDC_RADIO11                     178
#define IDC_RADIO12                     179
#define IDC_RADIO13                     180
#define IDC_EDIT1                       183
#define IDC_EDIT2                       184

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        181
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         185
#define _APS_NEXT_SYMED_VALUE           183
#endif
#endif
